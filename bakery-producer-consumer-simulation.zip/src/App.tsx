import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  ShieldCheck,
  AlertTriangle,
  Layers,
  Terminal,
  FileCode,
  BookOpen,
  Copy,
  Check,
  Sparkles,
  Download,
  Flame,
  Coffee,
  Users,
  Box,
  Lock,
  Unlock,
  Info,
  Clock,
  Search,
  Zap,
} from 'lucide-react';

// Bread types for visual delight
const BREAD_TYPES = [
  { icon: '🥖', name: 'French Baguette' },
  { icon: '🥐', name: 'Butter Croissant' },
  { icon: '🍞', name: 'Sourdough Loaf' },
  { icon: '🥯', name: 'Sesame Bagel' },
  { icon: '🥨', name: 'Bavarian Pretzel' },
];

interface ShelfItem {
  id: string;
  bakerId: number;
  loafNum: number;
  type: { icon: string; name: string };
  timestamp: string;
}

interface LogEntry {
  id: string;
  timestamp: string;
  type: 'placed' | 'took' | 'baker_blocked' | 'customer_blocked' | 'race' | 'info';
  message: string;
  shelfState: string;
  details?: string;
}

interface BakerState {
  id: number;
  name: string;
  totalToBake: number;
  bakedCount: number;
  state: 'idle' | 'baking' | 'blocked' | 'placing' | 'done';
  currentLoaf?: string;
}

interface CustomerState {
  id: number;
  name: string;
  quota: number;
  consumedCount: number;
  state: 'idle' | 'waiting' | 'blocked' | 'taking' | 'eating' | 'done';
  currentLoaf?: string;
}

export default function App() {
  // Tabs
  const [activeTab, setActiveTab] = useState<'simulation' | 'code' | 'terminal' | 'theory'>('simulation');
  const [selectedCodeFile, setSelectedCodeFile] = useState<'bakery.py' | 'bakery_queue.py' | 'README.md'>('bakery.py');
  const [copied, setCopied] = useState(false);

  // Configuration parameters
  const [shelfCapacity, setShelfCapacity] = useState<number>(5);
  const [numBakers, setNumBakers] = useState<number>(2);
  const [numCustomers, setNumCustomers] = useState<number>(2);
  const [loavesPerBaker, setLoavesPerBaker] = useState<number>(5);
  const [syncMode, setSyncMode] = useState<'mutex' | 'no-sync' | 'queue'>('mutex');
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);

  // Simulation execution state
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const [shelf, setShelf] = useState<ShelfItem[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [logFilter, setLogFilter] = useState<string>('all');
  const [logSearch, setLogSearch] = useState<string>('');
  const [autoScroll, setAutoScroll] = useState<boolean>(true);

  // Sync state tracking
  const [emptySemaphore, setEmptySemaphore] = useState<number>(5);
  const [fullSemaphore, setFullSemaphore] = useState<number>(0);
  const [mutexHolder, setMutexHolder] = useState<string | null>(null);
  const [raceHazardCount, setRaceHazardCount] = useState<number>(0);

  // Threads state
  const [bakers, setBakers] = useState<BakerState[]>([]);
  const [customers, setCustomers] = useState<CustomerState[]>([]);

  // Refs for animation loop
  const logsEndRef = useRef<HTMLDivElement>(null);
  const simStateRef = useRef({
    shelf: [] as ShelfItem[],
    empty: 5,
    full: 0,
    mutexLocked: false,
    mutexOwner: null as string | null,
    totalProduced: 0,
    totalConsumed: 0,
    targetTotal: 10,
    anomalies: 0,
  });

  // Keep ref synchronized with capacity and config
  useEffect(() => {
    resetSimulation();
  }, [shelfCapacity, numBakers, numCustomers, loavesPerBaker, syncMode]);

  // Auto-scroll logs
  useEffect(() => {
    if (autoScroll && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, autoScroll]);

  const getNowTimestamp = () => {
    const d = new Date();
    return d.toTimeString().split(' ')[0] + '.' + String(d.getMilliseconds()).padStart(3, '0');
  };

  const addLog = (entry: Omit<LogEntry, 'id'>) => {
    setLogs((prev) => [
      ...prev,
      {
        ...entry,
        id: Math.random().toString(36).substring(2, 9),
      },
    ]);
  };

  const resetSimulation = () => {
    setIsRunning(false);
    setIsFinished(false);
    setShelf([]);
    setLogs([]);
    setRaceHazardCount(0);
    setMutexHolder(null);

    const totalToProduce = numBakers * loavesPerBaker;
    const baseQuota = Math.floor(totalToProduce / numCustomers);
    const remainder = totalToProduce % numCustomers;

    const initialBakers: BakerState[] = Array.from({ length: numBakers }, (_, i) => ({
      id: i + 1,
      name: `Baker-${i + 1}`,
      totalToBake: loavesPerBaker,
      bakedCount: 0,
      state: 'idle',
    }));

    const initialCustomers: CustomerState[] = Array.from({ length: numCustomers }, (_, i) => ({
      id: i + 1,
      name: `Cust-${i + 1}`,
      quota: baseQuota + (i < remainder ? 1 : 0),
      consumedCount: 0,
      state: 'idle',
    }));

    setBakers(initialBakers);
    setCustomers(initialCustomers);
    setEmptySemaphore(shelfCapacity);
    setFullSemaphore(0);

    simStateRef.current = {
      shelf: [],
      empty: shelfCapacity,
      full: 0,
      mutexLocked: false,
      mutexOwner: null,
      totalProduced: 0,
      totalConsumed: 0,
      targetTotal: totalToProduce,
      anomalies: 0,
    };
  };

  // Run the simulation asynchronously
  useEffect(() => {
    if (!isRunning) return;

    let active = true;
    const targetTotal = numBakers * loavesPerBaker;
    const baseQuota = Math.floor(targetTotal / numCustomers);
    const remainder = targetTotal % numCustomers;
    const customerQuotas = Array.from({ length: numCustomers }, (_, i) => baseQuota + (i < remainder ? 1 : 0));

    addLog({
      timestamp: getNowTimestamp(),
      type: 'info',
      message: `Simulation started (${syncMode === 'mutex' ? 'Mutex + Semaphores' : syncMode === 'no-sync' ? 'NO MUTEX (Race Demo)' : 'queue.Queue'}). Target: ${targetTotal} loaves.`,
      shelfState: `shelf=0/${shelfCapacity}`,
    });

    // Helper sleep scaled by multiplier
    const simSleep = (ms: number) => new Promise((res) => setTimeout(res, ms / speedMultiplier));

    // Producer simulation routine
    const runBaker = async (bakerId: number) => {
      const bakerName = `Baker-${bakerId}`;
      for (let loafNum = 1; loafNum <= loavesPerBaker; loafNum++) {
        if (!active) return;

        // Baking phase
        setBakers((prev) =>
          prev.map((b) => (b.id === bakerId ? { ...b, state: 'baking', currentLoaf: `Baking loaf #${loafNum}` } : b))
        );
        await simSleep(250 + Math.random() * 350);
        if (!active) return;

        const loafId = `${bakerName}-loaf${loafNum}`;
        const breadType = BREAD_TYPES[(bakerId + loafNum) % BREAD_TYPES.length];

        // 1. Wait on empty semaphore
        if (simStateRef.current.empty <= 0) {
          setBakers((prev) =>
            prev.map((b) => (b.id === bakerId ? { ...b, state: 'blocked', currentLoaf: `Blocked: Shelf full (${shelfCapacity}/${shelfCapacity})` } : b))
          );
          addLog({
            timestamp: getNowTimestamp(),
            type: 'baker_blocked',
            message: `⚠️  ${bakerName} BLOCKED: shelf is full (${shelfCapacity}/${shelfCapacity}). Waiting for space...`,
            shelfState: `shelf=${simStateRef.current.shelf.length}/${shelfCapacity}`,
          });

          while (active && simStateRef.current.empty <= 0) {
            await simSleep(50);
          }
          if (!active) return;
        }

        // Decrement empty semaphore
        simStateRef.current.empty -= 1;
        setEmptySemaphore(simStateRef.current.empty);

        // 2. Acquire Mutex (unless --no-sync)
        if (syncMode === 'mutex') {
          while (active && simStateRef.current.mutexLocked) {
            await simSleep(25);
          }
          if (!active) return;
          simStateRef.current.mutexLocked = true;
          simStateRef.current.mutexOwner = bakerName;
          setMutexHolder(bakerName);
        } else if (syncMode === 'no-sync') {
          // In no-sync mode, multiple threads can access simultaneously!
          if (simStateRef.current.mutexOwner) {
            simStateRef.current.anomalies += 1;
            setRaceHazardCount(simStateRef.current.anomalies);
            addLog({
              timestamp: getNowTimestamp(),
              type: 'race',
              message: `🚨 RACE HAZARD: ${bakerName} placing loaf while ${simStateRef.current.mutexOwner} is still modifying shelf!`,
              shelfState: `shelf=${simStateRef.current.shelf.length}/${shelfCapacity}`,
              details: 'Concurrent buffer modification without mutex protection',
            });
          }
          simStateRef.current.mutexOwner = bakerName;
          setMutexHolder(`${bakerName} (UNPROTECTED)`);
        }

        // Critical section
        setBakers((prev) =>
          prev.map((b) => (b.id === bakerId ? { ...b, state: 'placing', currentLoaf: `Placing ${loafId}` } : b))
        );
        await simSleep(120);

        // Check if buffer overflowed in race mode
        if (simStateRef.current.shelf.length >= shelfCapacity) {
          simStateRef.current.anomalies += 1;
          setRaceHazardCount(simStateRef.current.anomalies);
          addLog({
            timestamp: getNowTimestamp(),
            type: 'race',
            message: `🚨 RACE HAZARD: ${bakerName} placed loaf beyond shelf limit (${simStateRef.current.shelf.length + 1}/${shelfCapacity})!`,
            shelfState: `shelf=${simStateRef.current.shelf.length + 1}/${shelfCapacity}`,
          });
        }

        const newItem: ShelfItem = {
          id: loafId,
          bakerId,
          loafNum,
          type: breadType,
          timestamp: getNowTimestamp(),
        };

        simStateRef.current.shelf.push(newItem);
        simStateRef.current.totalProduced += 1;
        setShelf([...simStateRef.current.shelf]);

        const currentCount = simStateRef.current.shelf.length;
        addLog({
          timestamp: getNowTimestamp(),
          type: 'placed',
          message: `🍞 ${bakerName} placed ${loafId} (${breadType.icon} ${breadType.name}) | shelf=${currentCount}/${shelfCapacity}`,
          shelfState: `shelf=${currentCount}/${shelfCapacity}`,
        });

        // Release Mutex
        if (syncMode === 'mutex') {
          simStateRef.current.mutexLocked = false;
          simStateRef.current.mutexOwner = null;
          setMutexHolder(null);
        } else if (syncMode === 'no-sync') {
          if (simStateRef.current.mutexOwner === bakerName) {
            simStateRef.current.mutexOwner = null;
            setMutexHolder(null);
          }
        }

        // 3. Signal full semaphore
        simStateRef.current.full += 1;
        setFullSemaphore(simStateRef.current.full);

        setBakers((prev) =>
          prev.map((b) => (b.id === bakerId ? { ...b, bakedCount: loafNum, state: loafNum === loavesPerBaker ? 'done' : 'idle', currentLoaf: undefined } : b))
        );
      }
    };

    // Consumer simulation routine
    const runCustomer = async (customerId: number, quota: number) => {
      const custName = `Cust-${customerId}`;

      for (let buyNum = 1; buyNum <= quota; buyNum++) {
        if (!active) return;

        // 1. Wait on full semaphore
        if (simStateRef.current.full <= 0) {
          setCustomers((prev) =>
            prev.map((c) => (c.id === customerId ? { ...c, state: 'blocked', currentLoaf: `Blocked: Shelf empty (0/${shelfCapacity})` } : c))
          );
          addLog({
            timestamp: getNowTimestamp(),
            type: 'customer_blocked',
            message: `⏳ ${custName} BLOCKED: shelf is empty (0/${shelfCapacity}). Waiting for fresh bread...`,
            shelfState: `shelf=${simStateRef.current.shelf.length}/${shelfCapacity}`,
          });

          while (active && simStateRef.current.full <= 0) {
            await simSleep(50);
          }
          if (!active) return;
        }

        // Decrement full semaphore
        simStateRef.current.full -= 1;
        setFullSemaphore(simStateRef.current.full);

        // 2. Acquire Mutex (unless --no-sync)
        if (syncMode === 'mutex') {
          while (active && simStateRef.current.mutexLocked) {
            await simSleep(25);
          }
          if (!active) return;
          simStateRef.current.mutexLocked = true;
          simStateRef.current.mutexOwner = custName;
          setMutexHolder(custName);
        } else if (syncMode === 'no-sync') {
          if (simStateRef.current.mutexOwner) {
            simStateRef.current.anomalies += 1;
            setRaceHazardCount(simStateRef.current.anomalies);
            addLog({
              timestamp: getNowTimestamp(),
              type: 'race',
              message: `🚨 RACE HAZARD: ${custName} taking bread concurrently with ${simStateRef.current.mutexOwner}!`,
              shelfState: `shelf=${simStateRef.current.shelf.length}/${shelfCapacity}`,
              details: 'Race condition on buffer extraction',
            });
          }
          simStateRef.current.mutexOwner = custName;
          setMutexHolder(`${custName} (UNPROTECTED)`);
        }

        // Critical section: pop item
        setCustomers((prev) =>
          prev.map((c) => (c.id === customerId ? { ...c, state: 'taking', currentLoaf: `Taking loaf...` } : c))
        );
        await simSleep(120);

        let itemTaken: ShelfItem | undefined;
        if (simStateRef.current.shelf.length === 0) {
          simStateRef.current.anomalies += 1;
          setRaceHazardCount(simStateRef.current.anomalies);
          addLog({
            timestamp: getNowTimestamp(),
            type: 'race',
            message: `🚨 RACE HAZARD: ${custName} attempted to pop from an empty shelf buffer!`,
            shelfState: `shelf=0/${shelfCapacity}`,
          });
        } else {
          itemTaken = simStateRef.current.shelf.shift();
        }

        simStateRef.current.totalConsumed += 1;
        setShelf([...simStateRef.current.shelf]);

        const remainingCount = simStateRef.current.shelf.length;
        addLog({
          timestamp: getNowTimestamp(),
          type: 'took',
          message: `🛒 ${custName} took   ${itemTaken ? itemTaken.id : 'NONE (CORRUPTED)'} | shelf=${remainingCount}/${shelfCapacity}`,
          shelfState: `shelf=${remainingCount}/${shelfCapacity}`,
        });

        // Release Mutex
        if (syncMode === 'mutex') {
          simStateRef.current.mutexLocked = false;
          simStateRef.current.mutexOwner = null;
          setMutexHolder(null);
        } else if (syncMode === 'no-sync') {
          if (simStateRef.current.mutexOwner === custName) {
            simStateRef.current.mutexOwner = null;
            setMutexHolder(null);
          }
        }

        // 3. Signal empty semaphore
        simStateRef.current.empty += 1;
        setEmptySemaphore(simStateRef.current.empty);

        // Eating phase
        setCustomers((prev) =>
          prev.map((c) =>
            c.id === customerId
              ? {
                  ...c,
                  consumedCount: buyNum,
                  state: buyNum === quota ? 'done' : 'eating',
                  currentLoaf: itemTaken ? `Eating ${itemTaken.type.icon}` : undefined,
                }
              : c
          )
        );
        await simSleep(250 + Math.random() * 350);
      }
    };

    // Run all threads
    const promises = [
      ...Array.from({ length: numBakers }, (_, i) => runBaker(i + 1)),
      ...Array.from({ length: numCustomers }, (_, i) => runCustomer(i + 1, customerQuotas[i])),
    ];

    Promise.all(promises).then(() => {
      if (active) {
        setIsRunning(false);
        setIsFinished(true);
        setMutexHolder(null);
        addLog({
          timestamp: getNowTimestamp(),
          type: 'info',
          message: `🎉 SIMULATION COMPLETE: ${targetTotal} produced == ${targetTotal} consumed. Final shelf: ${simStateRef.current.shelf.length}/${shelfCapacity}.`,
          shelfState: `shelf=${simStateRef.current.shelf.length}/${shelfCapacity}`,
        });
      }
    });

    return () => {
      active = false;
    };
  }, [isRunning]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadFile = (filename: string, content: string) => {
    const element = document.createElement('a');
    const file = new Blob([content], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  // Filtered logs
  const filteredLogs = logs.filter((log) => {
    if (logFilter === 'placed' && log.type !== 'placed') return false;
    if (logFilter === 'took' && log.type !== 'took') return false;
    if (logFilter === 'blocked' && log.type !== 'baker_blocked' && log.type !== 'customer_blocked') return false;
    if (logFilter === 'race' && log.type !== 'race') return false;
    if (logSearch.trim()) {
      return log.message.toLowerCase().includes(logSearch.toLowerCase()) || log.timestamp.includes(logSearch);
    }
    return true;
  });

  const totalTargetLoaves = numBakers * loavesPerBaker;
  const currentTotalConsumed = customers.reduce((acc, c) => acc + c.consumedCount, 0);
  const currentTotalBaked = bakers.reduce((acc, b) => acc + b.bakedCount, 0);

  // Content of code files
  const pythonBakeryCode = `#!/usr/bin/env python3
"""
Bakery Producer-Consumer Simulation
Demonstrates the classic Bounded-Buffer synchronization problem using POSIX-style
counting semaphores and a mutual exclusion lock in Python's threading library.
"""

import argparse
import datetime
import random
import sys
import threading
import time
from typing import List, Optional


def get_timestamp() -> str:
    return datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]


def log_event(message: str) -> None:
    sys.stdout.write(f"[{get_timestamp()}] {message}\\n")
    sys.stdout.flush()


class BakeryShelf:
    def __init__(self, capacity: int, use_mutex: bool = True):
        self.capacity = capacity
        self.use_mutex = use_mutex
        self.buffer: List[str] = []
        
        # 1. empty counts available shelf slots (initially N)
        self.empty = threading.Semaphore(capacity)
        # 2. full counts available loaves (initially 0)
        self.full = threading.Semaphore(0)
        # 3. mutex guarantees mutual exclusion in critical section
        self.mutex = threading.Lock()


def baker_worker(baker_id: int, loaves_to_bake: int, shelf: BakeryShelf):
    baker_name = f"Baker-{baker_id}"
    for loaf_num in range(1, loaves_to_bake + 1):
        loaf_id = f"{baker_name}-loaf{loaf_num}"
        time.sleep(random.uniform(0.05, 0.20))
        
        # Log if thread must block because shelf is full
        if not shelf.empty.acquire(blocking=False):
            log_event(f"⚠️  {baker_name} BLOCKED: shelf is full ({shelf.capacity}/{shelf.capacity}). Waiting for space...")
            shelf.empty.acquire()

        # =========================================================================
        # CRITICAL SECTION ACQUISITION ORDER EXPLANATION:
        # We MUST acquire \`empty\` BEFORE \`mutex\`!
        #
        # Why?
        # If Baker acquired \`mutex\` first and then blocked on \`empty\` when shelf is full,
        # the Baker would hold \`mutex\` while sleeping. A Customer needing to take
        # bread to free a slot would also need \`mutex\` -> DEADLOCK!
        # =========================================================================
        if shelf.use_mutex:
            shelf.mutex.acquire()
            
        try:
            shelf.buffer.append(loaf_id)
            log_event(f"🍞 {baker_name:<7} placed {loaf_id} | shelf={len(shelf.buffer)}/{shelf.capacity}")
        finally:
            if shelf.use_mutex:
                shelf.mutex.release()

        # Signal that a loaf is now available
        shelf.full.release()


def customer_worker(customer_id: int, loaves_to_buy: int, shelf: BakeryShelf):
    customer_name = f"Cust-{customer_id}"
    for _ in range(loaves_to_buy):
        # Log if thread must block because shelf is empty
        if not shelf.full.acquire(blocking=False):
            log_event(f"⏳ {customer_name} BLOCKED: shelf is empty (0/{shelf.capacity}). Waiting for fresh bread...")
            shelf.full.acquire()

        # Acquire \`full\` BEFORE \`mutex\` to prevent deadlock
        if shelf.use_mutex:
            shelf.mutex.acquire()
            
        loaf_taken = None
        try:
            loaf_taken = shelf.buffer.pop(0) if shelf.buffer else "ERROR_EMPTY"
            log_event(f"🛒 {customer_name:<7} took   {loaf_taken} | shelf={len(shelf.buffer)}/{shelf.capacity}")
        finally:
            if shelf.use_mutex:
                shelf.mutex.release()

        # Signal that a shelf slot has been freed
        shelf.empty.release()
        time.sleep(random.uniform(0.05, 0.20))
`;

  const pythonQueueCode = `#!/usr/bin/env python3
"""
Bakery Producer-Consumer Simulation using queue.Queue
Demonstrates the high-level, thread-safe queue approach for bounded-buffer synchronization.
"""

import argparse
import datetime
import queue
import random
import sys
import threading
import time


def get_timestamp() -> str:
    return datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]


def log_event(message: str) -> None:
    sys.stdout.write(f"[{get_timestamp()}] {message}\\n")
    sys.stdout.flush()


def baker_worker(baker_id: int, loaves_to_bake: int, shelf_queue: queue.Queue, shelf_capacity: int):
    baker_name = f"Baker-{baker_id}"
    for loaf_num in range(1, loaves_to_bake + 1):
        loaf_id = f"{baker_name}-loaf{loaf_num}"
        time.sleep(random.uniform(0.05, 0.20))
        
        if shelf_queue.full():
            log_event(f"⚠️  {baker_name} BLOCKED: queue is full ({shelf_capacity}/{shelf_capacity}). Waiting...")
        
        # queue.put automatically blocks when full and notifies not_empty
        shelf_queue.put(loaf_id, block=True)
        log_event(f"🍞 {baker_name:<7} placed {loaf_id} | shelf={shelf_queue.qsize()}/{shelf_capacity}")


def customer_worker(customer_id: int, loaves_to_buy: int, shelf_queue: queue.Queue, shelf_capacity: int):
    customer_name = f"Cust-{customer_id}"
    for _ in range(loaves_to_buy):
        if shelf_queue.empty():
            log_event(f"⏳ {customer_name} BLOCKED: queue is empty (0/{shelf_capacity}). Waiting...")

        # queue.get automatically blocks when empty and notifies not_full
        loaf_taken = shelf_queue.get(block=True)
        shelf_queue.task_done()
        log_event(f"🛒 {customer_name:<7} took   {loaf_taken} | shelf={shelf_queue.qsize()}/{shelf_capacity}")
        time.sleep(random.uniform(0.05, 0.20))
`;

  const readmeCode = `# Bakery Producer-Consumer Bounded-Buffer Simulation

## 🥐 Scenario
- Bakers (Producers) bake bread and place it on a bounded shelf (size N).
- Customers (Consumers) take bread from the shelf.
- The shelf is a shared bounded buffer.

## ⚙️ Three Synchronization Primitives
1. \`empty = Semaphore(N)\`: Free shelf slots (initially N)
2. \`full = Semaphore(0)\`: Loaves ready on shelf (initially 0)
3. \`mutex = Lock()\`: Mutual exclusion on the shelf buffer

## ⚠️ Deadlock Prevention: Acquisition Order
Always acquire \`empty\`/\`full\` BEFORE \`mutex\`!
If a thread acquires \`mutex\` first and then blocks on \`empty\`, it keeps \`mutex\` locked.
Consumers needing to take bread to signal \`empty\` cannot acquire \`mutex\` -> DEADLOCK.

## 🚀 Running
python3 bakery.py --shelf-size 5 --bakers 2 --customers 2 --loaves-per-baker 5
python3 bakery.py --shelf-size 2 --bakers 4 --customers 4 --no-sync
python3 bakery_queue.py
`;

  return (
    <div className="min-h-screen bg-stone-900 text-stone-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Navigation Bar */}
      <header className="border-b border-stone-800 bg-stone-950/80 backdrop-blur sticky top-0 z-50 px-4 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-amber-400 flex items-center justify-center shadow-lg shadow-amber-500/20 text-xl font-bold text-stone-950">
            🥐
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-tight text-white">Bakery Producer-Consumer Lab</h1>
              <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Bounded Buffer
              </span>
            </div>
            <p className="text-xs text-stone-400">Classic Synchronization Simulation in Python & Interactive Visualizer</p>
          </div>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center gap-1 bg-stone-900 p-1 rounded-xl border border-stone-800">
          <button
            onClick={() => setActiveTab('simulation')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
              activeTab === 'simulation' ? 'bg-amber-500 text-stone-950 font-semibold shadow' : 'text-stone-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" /> Live Simulation
          </button>
          <button
            onClick={() => setActiveTab('terminal')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
              activeTab === 'terminal' ? 'bg-amber-500 text-stone-950 font-semibold shadow' : 'text-stone-400 hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" /> Python Output
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
              activeTab === 'code' ? 'bg-amber-500 text-stone-950 font-semibold shadow' : 'text-stone-400 hover:text-white'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" /> Source Files
          </button>
          <button
            onClick={() => setActiveTab('theory')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
              activeTab === 'theory' ? 'bg-amber-500 text-stone-950 font-semibold shadow' : 'text-stone-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" /> Deadlock & Semaphores
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 p-4 lg:p-6 max-w-7xl mx-auto w-full flex flex-col gap-6">
        {activeTab === 'simulation' && (
          <>
            {/* Control Dashboard */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              {/* Settings Panel */}
              <div className="lg:col-span-8 bg-stone-950 border border-stone-800/80 rounded-2xl p-4 lg:p-5 flex flex-col gap-4 shadow-xl">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800/60 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 text-sm font-semibold">Simulation Parameters</span>
                    <span className="text-xs text-stone-400">(Configurable CLI Arguments)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      disabled={isRunning}
                      onClick={() => setSyncMode('mutex')}
                      className={`px-2.5 py-1 text-xs rounded-lg border transition flex items-center gap-1 ${
                        syncMode === 'mutex'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-medium'
                          : 'bg-stone-900 text-stone-400 border-stone-800 hover:text-stone-200'
                      }`}
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      Mutex (Thread-Safe)
                    </button>
                    <button
                      disabled={isRunning}
                      onClick={() => setSyncMode('no-sync')}
                      className={`px-2.5 py-1 text-xs rounded-lg border transition flex items-center gap-1 ${
                        syncMode === 'no-sync'
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 font-medium'
                          : 'bg-stone-900 text-stone-400 border-stone-800 hover:text-stone-200'
                      }`}
                    >
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                      --no-sync (Race Demo)
                    </button>
                    <button
                      disabled={isRunning}
                      onClick={() => setSyncMode('queue')}
                      className={`px-2.5 py-1 text-xs rounded-lg border transition flex items-center gap-1 ${
                        syncMode === 'queue'
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 font-medium'
                          : 'bg-stone-900 text-stone-400 border-stone-800 hover:text-stone-200'
                      }`}
                    >
                      <Zap className="w-3.5 h-3.5 text-cyan-400" />
                      queue.Queue
                    </button>
                  </div>
                </div>

                {/* Sliders Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="bg-stone-900/60 p-3 rounded-xl border border-stone-800/60">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs text-stone-400 font-medium">Shelf Size (N)</label>
                      <span className="text-xs font-bold text-amber-400">{shelfCapacity}</span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={10}
                      disabled={isRunning}
                      value={shelfCapacity}
                      onChange={(e) => setShelfCapacity(Number(e.target.value))}
                      className="w-full accent-amber-500 bg-stone-800 h-1.5 rounded-lg cursor-pointer disabled:opacity-40"
                    />
                    <span className="text-[10px] text-stone-400">Bounded buffer capacity</span>
                  </div>

                  <div className="bg-stone-900/60 p-3 rounded-xl border border-stone-800/60">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs text-stone-400 font-medium">Bakers</label>
                      <span className="text-xs font-bold text-amber-400">{numBakers}</span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={6}
                      disabled={isRunning}
                      value={numBakers}
                      onChange={(e) => setNumBakers(Number(e.target.value))}
                      className="w-full accent-amber-500 bg-stone-800 h-1.5 rounded-lg cursor-pointer disabled:opacity-40"
                    />
                    <span className="text-[10px] text-stone-400">Producer threads</span>
                  </div>

                  <div className="bg-stone-900/60 p-3 rounded-xl border border-stone-800/60">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs text-stone-400 font-medium">Customers</label>
                      <span className="text-xs font-bold text-amber-400">{numCustomers}</span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={6}
                      disabled={isRunning}
                      value={numCustomers}
                      onChange={(e) => setNumCustomers(Number(e.target.value))}
                      className="w-full accent-amber-500 bg-stone-800 h-1.5 rounded-lg cursor-pointer disabled:opacity-40"
                    />
                    <span className="text-[10px] text-stone-400">Consumer threads</span>
                  </div>

                  <div className="bg-stone-900/60 p-3 rounded-xl border border-stone-800/60">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs text-stone-400 font-medium">Loaves / Baker</label>
                      <span className="text-xs font-bold text-amber-400">{loavesPerBaker}</span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={10}
                      disabled={isRunning}
                      value={loavesPerBaker}
                      onChange={(e) => setLoavesPerBaker(Number(e.target.value))}
                      className="w-full accent-amber-500 bg-stone-800 h-1.5 rounded-lg cursor-pointer disabled:opacity-40"
                    />
                    <span className="text-[10px] text-stone-400">Total: {numBakers * loavesPerBaker} loaves</span>
                  </div>
                </div>

                {/* Bottom action bar */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <div className="flex items-center gap-3">
                    {!isRunning ? (
                      <button
                        onClick={() => setIsRunning(true)}
                        className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 transition active:scale-95"
                      >
                        <Play className="w-4 h-4 fill-current" />
                        {isFinished ? 'Run Again' : 'Start Simulation'}
                      </button>
                    ) : (
                      <button
                        onClick={() => setIsRunning(false)}
                        className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-600/20 transition active:scale-95"
                      >
                        <Pause className="w-4 h-4" />
                        Pause
                      </button>
                    )}
                    <button
                      onClick={resetSimulation}
                      className="px-3.5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 text-xs font-medium border border-stone-800 flex items-center gap-1.5 transition"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Reset
                    </button>
                  </div>

                  <div className="flex items-center gap-2 bg-stone-900 px-3 py-1.5 rounded-xl border border-stone-800 text-xs">
                    <span className="text-stone-400">Speed:</span>
                    {[0.5, 1, 2, 4].map((mult) => (
                      <button
                        key={mult}
                        onClick={() => setSpeedMultiplier(mult)}
                        className={`px-2 py-0.5 rounded text-[11px] font-mono ${
                          speedMultiplier === mult ? 'bg-amber-500 text-stone-950 font-bold' : 'text-stone-400 hover:text-white'
                        }`}
                      >
                        {mult}x
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Live Synchronization Primitives State */}
              <div className="lg:col-span-4 bg-stone-950 border border-stone-800/80 rounded-2xl p-4 lg:p-5 flex flex-col justify-between shadow-xl">
                <div>
                  <div className="flex items-center justify-between border-b border-stone-800/60 pb-3 mb-3">
                    <span className="text-xs font-semibold uppercase tracking-wider text-stone-400">Synchronization State</span>
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-stone-900 border border-stone-800 text-stone-300">
                      POSIX Style
                    </span>
                  </div>

                  <div className="space-y-3">
                    {/* empty Semaphore */}
                    <div className="flex items-center justify-between bg-stone-900/60 p-2.5 rounded-xl border border-stone-800/60">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full bg-blue-400" />
                        <div>
                          <p className="text-xs font-mono font-medium text-stone-200">empty = Semaphore(N)</p>
                          <p className="text-[10px] text-stone-400">Free slots on shelf</p>
                        </div>
                      </div>
                      <span className="text-base font-mono font-bold text-blue-400 bg-blue-500/10 px-2.5 py-0.5 rounded border border-blue-500/20">
                        {emptySemaphore}
                      </span>
                    </div>

                    {/* full Semaphore */}
                    <div className="flex items-center justify-between bg-stone-900/60 p-2.5 rounded-xl border border-stone-800/60">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                        <div>
                          <p className="text-xs font-mono font-medium text-stone-200">full = Semaphore(0)</p>
                          <p className="text-[10px] text-stone-400">Loaves available to take</p>
                        </div>
                      </div>
                      <span className="text-base font-mono font-bold text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded border border-amber-500/20">
                        {fullSemaphore}
                      </span>
                    </div>

                    {/* mutex Lock */}
                    <div className="flex items-center justify-between bg-stone-900/60 p-2.5 rounded-xl border border-stone-800/60">
                      <div className="flex items-center gap-2">
                        {mutexHolder ? (
                          <Lock className="w-3.5 h-3.5 text-rose-400" />
                        ) : (
                          <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                        )}
                        <div>
                          <p className="text-xs font-mono font-medium text-stone-200">mutex = Lock()</p>
                          <p className="text-[10px] text-stone-400">
                            {syncMode === 'no-sync' ? 'DISABLED (--no-sync)' : mutexHolder ? `Held by ${mutexHolder}` : 'Unlocked (Free)'}
                          </p>
                        </div>
                      </div>
                      <span
                        className={`text-[11px] font-mono font-medium px-2 py-0.5 rounded border ${
                          syncMode === 'no-sync'
                            ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                            : mutexHolder
                            ? 'bg-rose-500/10 text-rose-400 border-rose-500/20 animate-pulse'
                            : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        }`}
                      >
                        {syncMode === 'no-sync' ? 'OMITTED' : mutexHolder ? 'LOCKED' : 'UNLOCKED'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Deadlock safety reminder */}
                <div className="mt-3 p-2.5 rounded-xl bg-amber-500/5 border border-amber-500/20 text-[11px] text-stone-300 flex items-start gap-2">
                  <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-amber-300">Acquire Order:</span> Semaphores are acquired <i>before</i> mutex to prevent circular deadlock!
                  </div>
                </div>
              </div>
            </div>

            {/* Bounded Buffer (Bakery Shelf Visualizer) */}
            <div className="bg-stone-950 border border-stone-800/80 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800/60 pb-3">
                <div className="flex items-center gap-2">
                  <Box className="w-4 h-4 text-amber-400" />
                  <h2 className="text-sm font-bold text-white">Bakery Shelf (Shared Bounded Buffer)</h2>
                  <span className="text-xs text-stone-400 font-mono">
                    [{shelf.length}/{shelfCapacity} Slots Occupied]
                  </span>
                </div>
                <div className="flex items-center gap-4 text-xs font-mono">
                  <span className="text-stone-400">
                    Produced: <strong className="text-amber-400">{currentTotalBaked}</strong>/{totalTargetLoaves}
                  </span>
                  <span className="text-stone-400">
                    Consumed: <strong className="text-emerald-400">{currentTotalConsumed}</strong>/{totalTargetLoaves}
                  </span>
                  {raceHazardCount > 0 && (
                    <span className="text-rose-400 font-bold flex items-center gap-1 animate-pulse">
                      <AlertTriangle className="w-3.5 h-3.5" /> {raceHazardCount} Race Hazards
                    </span>
                  )}
                </div>
              </div>

              {/* The Wooden Bakery Shelf */}
              <div className="relative bg-gradient-to-b from-stone-900 to-stone-950 border-2 border-amber-950/60 rounded-2xl p-6 shadow-inner">
                {/* Visual Shelf Rack Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                  {Array.from({ length: shelfCapacity }, (_, index) => {
                    const item = shelf[index];
                    return (
                      <div
                        key={index}
                        className={`h-28 rounded-xl border flex flex-col items-center justify-center p-2 relative transition-all duration-300 ${
                          item
                            ? 'bg-amber-950/30 border-amber-700/60 shadow-lg shadow-amber-900/20 scale-[1.02]'
                            : 'bg-stone-900/40 border-stone-800/60 border-dashed'
                        }`}
                      >
                        <span className="absolute top-1.5 left-2 text-[10px] font-mono text-stone-400">
                          Slot #{index + 1}
                        </span>

                        {item ? (
                          <div className="flex flex-col items-center text-center animate-bounce-short">
                            <span className="text-3xl filter drop-shadow">{item.type.icon}</span>
                            <span className="text-xs font-bold text-amber-300 mt-1 line-clamp-1">{item.id}</span>
                            <span className="text-[10px] text-stone-400 font-mono">{item.type.name}</span>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center text-stone-400">
                            <span className="text-lg">🪹</span>
                            <span className="text-[10px] font-mono uppercase tracking-wider">Empty</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Wooden Rack Shelf Base */}
                <div className="mt-4 h-3 bg-gradient-to-r from-amber-900 via-amber-700 to-amber-900 rounded-full shadow-lg border-t border-amber-600/40" />
              </div>
            </div>

            {/* Threads Display: Bakers (Producers) & Customers (Consumers) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Bakers Panel */}
              <div className="bg-stone-950 border border-stone-800/80 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
                <div className="flex items-center justify-between border-b border-stone-800/60 pb-2">
                  <div className="flex items-center gap-2">
                    <Flame className="w-4 h-4 text-amber-500" />
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">Bakers (Producer Threads)</h3>
                  </div>
                  <span className="text-xs text-stone-400 font-mono">{numBakers} active threads</span>
                </div>

                <div className="space-y-2">
                  {bakers.map((baker) => (
                    <div
                      key={baker.id}
                      className="bg-stone-900/60 border border-stone-800/70 p-3 rounded-xl flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-lg">
                          👨‍🍳
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-stone-100">{baker.name}</span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded font-mono font-medium ${
                                baker.state === 'baking'
                                  ? 'bg-amber-500/20 text-amber-300 animate-pulse'
                                  : baker.state === 'blocked'
                                  ? 'bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30'
                                  : baker.state === 'placing'
                                  ? 'bg-emerald-500/20 text-emerald-300'
                                  : baker.state === 'done'
                                  ? 'bg-stone-800 text-stone-400'
                                  : 'bg-stone-900 text-stone-400'
                              }`}
                            >
                              {baker.state === 'baking' && '🔥 Baking...'}
                              {baker.state === 'blocked' && '⚠️ BLOCKED (Shelf Full)'}
                              {baker.state === 'placing' && '📦 Placing on Shelf'}
                              {baker.state === 'done' && '✅ Completed'}
                              {baker.state === 'idle' && 'Idle'}
                            </span>
                          </div>
                          <p className="text-[11px] text-stone-400 mt-0.5">
                            {baker.currentLoaf || `Baked ${baker.bakedCount} of ${baker.totalToBake} loaves`}
                          </p>
                        </div>
                      </div>

                      <div className="w-24 text-right">
                        <div className="text-xs font-mono font-bold text-amber-400">
                          {baker.bakedCount}/{baker.totalToBake}
                        </div>
                        <div className="w-full bg-stone-800 h-1.5 rounded-full mt-1 overflow-hidden">
                          <div
                            className="bg-amber-500 h-full rounded-full transition-all duration-300"
                            style={{ width: `${(baker.bakedCount / baker.totalToBake) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Customers Panel */}
              <div className="bg-stone-950 border border-stone-800/80 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
                <div className="flex items-center justify-between border-b border-stone-800/60 pb-2">
                  <div className="flex items-center gap-2">
                    <Coffee className="w-4 h-4 text-emerald-400" />
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">Customers (Consumer Threads)</h3>
                  </div>
                  <span className="text-xs text-stone-400 font-mono">{numCustomers} active threads</span>
                </div>

                <div className="space-y-2">
                  {customers.map((cust) => (
                    <div
                      key={cust.id}
                      className="bg-stone-900/60 border border-stone-800/70 p-3 rounded-xl flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-lg">
                          😋
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-stone-100">{cust.name}</span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded font-mono font-medium ${
                                cust.state === 'waiting'
                                  ? 'bg-blue-500/20 text-blue-300'
                                  : cust.state === 'blocked'
                                  ? 'bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30'
                                  : cust.state === 'taking'
                                  ? 'bg-amber-500/20 text-amber-300'
                                  : cust.state === 'eating'
                                  ? 'bg-emerald-500/20 text-emerald-300 animate-pulse'
                                  : cust.state === 'done'
                                  ? 'bg-stone-800 text-stone-400'
                                  : 'bg-stone-900 text-stone-400'
                              }`}
                            >
                              {cust.state === 'waiting' && '👀 Waiting'}
                              {cust.state === 'blocked' && '⏳ BLOCKED (Shelf Empty)'}
                              {cust.state === 'taking' && '🛒 Taking Bread'}
                              {cust.state === 'eating' && '🥖 Eating...'}
                              {cust.state === 'done' && '✅ Satisfied'}
                              {cust.state === 'idle' && 'Idle'}
                            </span>
                          </div>
                          <p className="text-[11px] text-stone-400 mt-0.5">
                            {cust.currentLoaf || `Consumed ${cust.consumedCount} of ${cust.quota} quota (uneven split handled)`}
                          </p>
                        </div>
                      </div>

                      <div className="w-24 text-right">
                        <div className="text-xs font-mono font-bold text-emerald-400">
                          {cust.consumedCount}/{cust.quota}
                        </div>
                        <div className="w-full bg-stone-800 h-1.5 rounded-full mt-1 overflow-hidden">
                          <div
                            className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                            style={{ width: `${(cust.consumedCount / cust.quota) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Timestamped Event Logs Console */}
            <div className="bg-stone-950 border border-stone-800/80 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800/60 pb-3">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-amber-400" />
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">Timestamped Thread Event Log</h3>
                  <span className="text-xs text-stone-400 font-mono">({filteredLogs.length} events)</span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Search box */}
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-stone-400" />
                    <input
                      type="text"
                      placeholder="Search logs..."
                      value={logSearch}
                      onChange={(e) => setLogSearch(e.target.value)}
                      className="pl-8 pr-3 py-1 bg-stone-900 border border-stone-800 rounded-lg text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* Filter tags */}
                  {['all', 'placed', 'took', 'blocked', 'race'].map((tag) => (
                    <button
                      key={tag}
                      onClick={() => setLogFilter(tag)}
                      className={`px-2.5 py-1 text-xs rounded-lg capitalize font-mono transition ${
                        logFilter === tag ? 'bg-amber-500 text-stone-950 font-bold' : 'bg-stone-900 text-stone-400 hover:text-white'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}

                  <label className="flex items-center gap-1.5 text-xs text-stone-400 cursor-pointer ml-2">
                    <input
                      type="checkbox"
                      checked={autoScroll}
                      onChange={(e) => setAutoScroll(e.target.checked)}
                      className="accent-amber-500"
                    />
                    Auto-scroll
                  </label>

                  <button
                    onClick={() => {
                      const text = logs.map((l) => `[${l.timestamp}] ${l.message}`).join('\n');
                      copyToClipboard(text);
                    }}
                    className="px-2.5 py-1 bg-stone-900 hover:bg-stone-800 border border-stone-800 text-stone-300 rounded-lg text-xs flex items-center gap-1"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    Copy
                  </button>
                </div>
              </div>

              {/* Log Feed */}
              <div className="bg-stone-900/70 border border-stone-800/80 rounded-xl p-3 h-64 overflow-y-auto font-mono text-xs space-y-1.5 scrollbar-thin">
                {filteredLogs.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-stone-400">
                    No logs yet. Press "Start Simulation" to begin tracking thread events.
                  </div>
                ) : (
                  filteredLogs.map((log) => (
                    <div
                      key={log.id}
                      className={`p-1.5 rounded transition flex items-start gap-2 ${
                        log.type === 'baker_blocked'
                          ? 'bg-rose-950/40 text-rose-300 border border-rose-900/40'
                          : log.type === 'customer_blocked'
                          ? 'bg-amber-950/30 text-amber-300 border border-amber-900/40'
                          : log.type === 'race'
                          ? 'bg-rose-900/60 text-white font-bold border border-rose-500 animate-pulse'
                          : log.type === 'placed'
                          ? 'text-amber-100 hover:bg-stone-800/50'
                          : log.type === 'took'
                          ? 'text-emerald-300 hover:bg-stone-800/50'
                          : 'text-stone-300'
                      }`}
                    >
                      <span className="text-stone-400 shrink-0">[{log.timestamp}]</span>
                      <span className="flex-1">{log.message}</span>
                    </div>
                  ))
                )}
                <div ref={logsEndRef} />
              </div>
            </div>
          </>
        )}

        {/* Python Output & Terminal Verification Tab */}
        {activeTab === 'terminal' && (
          <div className="bg-stone-950 border border-stone-800/80 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800/60 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-amber-400" />
                  Verified Python Terminal Runs
                </h2>
                <p className="text-xs text-stone-400 mt-1">
                  Actual execution outputs recorded directly from Python 3.10 runtime using the deliverables in the workspace.
                </p>
              </div>
              <span className="px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-mono font-medium">
                Runtime: Python 3.10.12 (POSIX Threads)
              </span>
            </div>

            {/* Test Case 1: Standard Run */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-400 font-mono">1. Standard Run: python3 bakery.py</span>
                <span className="text-[11px] text-stone-400">Defaults: 5 shelf slots, 2 bakers, 2 customers, 5 loaves each</span>
              </div>
              <pre className="bg-stone-900/80 border border-stone-800 p-4 rounded-xl text-xs font-mono text-stone-200 overflow-x-auto leading-relaxed">
{`======================================================================
🥐 BAKERY PRODUCER-CONSUMER BOUNDED-BUFFER SIMULATION
======================================================================
Configuration:
  • Shelf Capacity (N) : 5 loaves
  • Bakers (Producers) : 2 threads (5 loaves each)
  • Customers (Consumers): 2 threads (quotas: [5, 5])
  • Total Loaves       : 10 produced == 10 consumed
  • Synchronization    : MUTEX + SEMAPHORES (Thread-safe)
======================================================================
[16:58:22.325] ⏳ Cust-1 BLOCKED: shelf is empty (0/5). Waiting for fresh bread...
[16:58:22.325] ⏳ Cust-2 BLOCKED: shelf is empty (0/5). Waiting for fresh bread...
[16:58:22.509] 🍞 Baker-1 placed Baker-1-loaf1 | shelf=1/5
[16:58:22.509] 🛒 Cust-1  took   Baker-1-loaf1 | shelf=0/5
[16:58:22.513] 🍞 Baker-2 placed Baker-2-loaf1 | shelf=1/5
[16:58:22.514] 🛒 Cust-2  took   Baker-2-loaf1 | shelf=0/5
[16:58:22.566] 🍞 Baker-2 placed Baker-2-loaf2 | shelf=1/5
[16:58:22.573] 🛒 Cust-1  took   Baker-2-loaf2 | shelf=0/5
...
======================================================================
📋 SIMULATION SUMMARY
======================================================================
Total Produced : 10 loaves
Total Consumed : 10 loaves
Final Shelf    : 0/5 loaves remaining on shelf
Items on Shelf : []
Execution Time : 0.88 seconds

✅ Verification Successful: All loaves safely produced, synchronized, and consumed!
   Buffer stayed strictly within bounded capacity [0, N] without deadlocks or races.`}
              </pre>
            </div>

            {/* Test Case 2: Baker Blocking (Shelf Full) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-400 font-mono">
                  2. Baker Blocking When Shelf is Full: python3 bakery.py --shelf-size 2 --bakers 3 --customers 1 --loaves-per-baker 3
                </span>
                <span className="text-[11px] text-stone-400">Capacity 2, high production rate</span>
              </div>
              <pre className="bg-stone-900/80 border border-stone-800 p-4 rounded-xl text-xs font-mono text-stone-200 overflow-x-auto leading-relaxed">
{`[16:58:26.737] ⏳ Cust-1 BLOCKED: shelf is empty (0/2). Waiting for fresh bread...
[16:58:26.801] 🍞 Baker-2 placed Baker-2-loaf1 | shelf=1/2
[16:58:26.801] 🛒 Cust-1  took   Baker-2-loaf1 | shelf=0/2
[16:58:26.838] 🍞 Baker-3 placed Baker-3-loaf1 | shelf=1/2
[16:58:26.868] 🍞 Baker-2 placed Baker-2-loaf2 | shelf=2/2
[16:58:26.917] 🍞 Baker-1 placed Baker-1-loaf1 | shelf=2/2
[16:58:26.940] ⚠️  Baker-3 BLOCKED: shelf is full (2/2). Waiting for space...
[16:58:27.004] ⚠️  Baker-2 BLOCKED: shelf is full (2/2). Waiting for space...
[16:58:27.015] ⚠️  Baker-1 BLOCKED: shelf is full (2/2). Waiting for space...
...
Total Produced : 9 loaves
Total Consumed : 9 loaves
Final Shelf    : 0/2 loaves remaining on shelf`}
              </pre>
            </div>

            {/* Test Case 3: Race Condition Demonstration (--no-sync) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-400 font-mono">
                  3. Race Condition Demo: python3 bakery.py --no-sync
                </span>
                <span className="text-[11px] text-rose-400 font-medium">Mutex omitted</span>
              </div>
              <pre className="bg-stone-900/80 border border-stone-800 p-4 rounded-xl text-xs font-mono text-stone-200 overflow-x-auto leading-relaxed">
{`⚠️  WARNING: Running in --no-sync mode!
   The shelf critical section is unprotected by a mutex lock.
   Watch for race conditions, corrupted buffers, or unexpected states.
----------------------------------------------------------------------
🔎 RACE CONDITION ANALYSIS (--no-sync):
What went wrong without the mutex?
1. Non-atomic buffer operations: Python's list.append() and list.pop(0) can
   interleave during thread context switches, leading to overwritten elements,
   lost updates, or attempting to pop from an empty list.
2. Desynchronized state: A thread might read len(buffer) while another is halfway
   through modifying it, violating bounded-buffer invariants (capacity limits).
3. Mutex is essential to ensure only ONE thread accesses the shelf structure at a time.`}
              </pre>
            </div>

            {/* Test Case 4: queue.Queue Comparison */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-cyan-400 font-mono">
                  4. High-Level Comparison: python3 bakery_queue.py
                </span>
                <span className="text-[11px] text-cyan-400 font-medium">Standard library queue.Queue</span>
              </div>
              <pre className="bg-stone-900/80 border border-stone-800 p-4 rounded-xl text-xs font-mono text-stone-200 overflow-x-auto leading-relaxed">
{`======================================================================
🥐 BAKERY PRODUCER-CONSUMER SIMULATION (using queue.Queue)
======================================================================
💡 Comparison with bakery.py (Semaphores + Mutex):
  • queue.Queue encapsulates all low-level synchronization details:
    - Uses threading.Condition for not_full and not_empty
    - Uses internal Lock to protect queue state (collections.deque)
    - Automatically prevents deadlocks that could arise from incorrect lock ordering.
  • bakery.py demonstrates the explicit foundational primitives (Dijkstra's counting semaphores).`}
              </pre>
            </div>
          </div>
        )}

        {/* Source Files Tab */}
        {activeTab === 'code' && (
          <div className="bg-stone-950 border border-stone-800/80 rounded-2xl p-6 shadow-xl flex flex-col gap-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800/60 pb-3">
              <div className="flex items-center gap-2">
                <FileCode className="w-5 h-5 text-amber-400" />
                <span className="text-sm font-bold text-white">Project Deliverable Source Code</span>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex bg-stone-900 p-1 rounded-xl border border-stone-800">
                  {(['bakery.py', 'bakery_queue.py', 'README.md'] as const).map((file) => (
                    <button
                      key={file}
                      onClick={() => setSelectedCodeFile(file)}
                      className={`px-3 py-1 rounded-lg text-xs font-mono transition ${
                        selectedCodeFile === file ? 'bg-amber-500 text-stone-950 font-bold' : 'text-stone-400 hover:text-white'
                      }`}
                    >
                      {file}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => {
                    const content =
                      selectedCodeFile === 'bakery.py'
                        ? pythonBakeryCode
                        : selectedCodeFile === 'bakery_queue.py'
                        ? pythonQueueCode
                        : readmeCode;
                    copyToClipboard(content);
                  }}
                  className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 border border-stone-800 text-stone-300 rounded-lg text-xs flex items-center gap-1.5"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copied!' : 'Copy File'}
                </button>

                <button
                  onClick={() => {
                    const content =
                      selectedCodeFile === 'bakery.py'
                        ? pythonBakeryCode
                        : selectedCodeFile === 'bakery_queue.py'
                        ? pythonQueueCode
                        : readmeCode;
                    downloadFile(selectedCodeFile, content);
                  }}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-lg text-xs flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download
                </button>
              </div>
            </div>

            <pre className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl text-xs font-mono text-stone-200 overflow-x-auto max-h-[550px] leading-relaxed scrollbar-thin">
              {selectedCodeFile === 'bakery.py' && pythonBakeryCode}
              {selectedCodeFile === 'bakery_queue.py' && pythonQueueCode}
              {selectedCodeFile === 'README.md' && readmeCode}
            </pre>
          </div>
        )}

        {/* Theory & Deadlock Prevention Tab */}
        {activeTab === 'theory' && (
          <div className="bg-stone-950 border border-stone-800/80 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-amber-400" />
                Synchronization Theory & Deadlock Analysis
              </h2>
              <p className="text-xs text-stone-400 mt-1">
                Understanding Dijkstra's bounded-buffer solution, acquisition ordering, and race condition mechanics.
              </p>
            </div>

            {/* Pseudocode Box */}
            <div className="bg-stone-900/80 border border-stone-800 p-5 rounded-2xl">
              <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2 font-mono">
                Classical Bounded-Buffer Pseudocode
              </h3>
              <pre className="text-xs font-mono text-stone-300 leading-relaxed overflow-x-auto">
{`// Shared synchronization primitives
empty = Semaphore(N)  // Free slots (initially N)
full  = Semaphore(0)  // Available loaves (initially 0)
mutex = Lock()        // Mutual exclusion for shelf buffer

procedure Producer_Baker():
    while true:
        loaf = bake_bread()
        
        wait(empty)          // 1. Wait until at least 1 free slot exists
        acquire(mutex)       // 2. Lock shelf before accessing buffer
        
        shelf.append(loaf)   // [CRITICAL SECTION]
        
        release(mutex)       // 3. Unlock shelf
        signal(full)         // 4. Notify consumers that a loaf is ready

procedure Consumer_Customer():
    while true:
        wait(full)           // 1. Wait until at least 1 loaf is available
        acquire(mutex)       // 2. Lock shelf before accessing buffer
        
        loaf = shelf.pop(0)  // [CRITICAL SECTION]
        
        release(mutex)       // 3. Unlock shelf
        signal(empty)        // 4. Notify producers that a slot is free
        
        consume(loaf)`}
              </pre>
            </div>

            {/* Deadlock analysis grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-emerald-950/20 border border-emerald-500/30 p-4 rounded-xl">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase font-mono">
                  <ShieldCheck className="w-4 h-4" /> Correct Ordering (No Deadlock)
                </div>
                <div className="text-xs font-mono mt-2 space-y-1 text-stone-300">
                  <p className="text-emerald-300">empty.acquire()</p>
                  <p className="text-emerald-300">mutex.acquire()</p>
                  <p className="text-stone-400">// ... critical section ...</p>
                  <p className="text-emerald-300">mutex.release()</p>
                  <p className="text-emerald-300">full.release()</p>
                </div>
                <p className="text-xs text-stone-300 mt-3 leading-relaxed">
                  If the shelf is full, the Baker blocks on <code className="text-amber-300">empty</code> <strong>before</strong> acquiring the mutex.
                  The customer is free to acquire <code className="text-amber-300">mutex</code>, consume a loaf, and signal <code className="text-amber-300">empty</code>.
                </p>
              </div>

              <div className="bg-rose-950/20 border border-rose-500/30 p-4 rounded-xl">
                <div className="flex items-center gap-2 text-rose-400 font-bold text-xs uppercase font-mono">
                  <AlertTriangle className="w-4 h-4" /> Reversing Order (Deadlock Trap)
                </div>
                <div className="text-xs font-mono mt-2 space-y-1 text-stone-300">
                  <p className="text-rose-400">mutex.acquire()   // ❌ LOCKED FIRST</p>
                  <p className="text-rose-400">empty.acquire()   // ❌ BLOCKS HOLDING MUTEX!</p>
                  <p className="text-stone-400">// ... never reached ...</p>
                </div>
                <p className="text-xs text-stone-300 mt-3 leading-relaxed">
                  If the shelf is full, the Baker acquires <code className="text-rose-300">mutex</code> and then blocks on <code className="text-rose-300">empty</code>.
                  The customer tries to consume bread but cannot acquire <code className="text-rose-300">mutex</code>.
                  Both threads freeze forever in circular wait!
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-800 bg-stone-950/80 px-4 lg:px-8 py-3 text-center text-xs text-stone-500 flex flex-wrap items-center justify-between gap-2">
        <span>Bakery Bounded-Buffer Producer-Consumer Simulation • Python 3.10 POSIX Semaphores</span>
        <div className="flex items-center gap-4">
          <span className="font-mono text-stone-400">Files: bakery.py • bakery_queue.py • README.md</span>
        </div>
      </footer>
    </div>
  );
}
