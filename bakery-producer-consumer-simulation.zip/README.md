# Bakery Producer-Consumer Bounded-Buffer Simulation

A comprehensive Python demonstration of the classic **Bounded-Buffer Synchronization Problem** using multi-threading.

---

## 🥐 Problem Scenario

- **Bakers (Producers)** bake loaves of bread and place them onto a shared bakery shelf.
- **Customers (Consumers)** purchase loaves of bread from the shelf and eat them.
- **Bakery Shelf (Bounded Buffer)** has a fixed maximum capacity of $N$ loaves.

### The Synchronization Challenges:
1. **Buffer Overflow**: A baker must **not** attempt to place bread when the shelf is full ($N/N$).
2. **Buffer Underflow**: A customer must **not** attempt to take bread when the shelf is empty ($0/N$).
3. **Mutual Exclusion (Race Conditions)**: Multiple bakers and customers must **never** modify the shelf simultaneously (e.g., corrupting list indices, double-popping items, or reading inconsistent lengths).
4. **Deadlock Prevention**: The order of acquiring synchronization primitives must avoid circular wait conditions.

---

## ⚙️ The Three Synchronization Primitives

The solution in `bakery.py` employs Dijkstra's classical counting semaphores and a mutual exclusion lock:

| Primitive | Initial Value | Purpose |
| :--- | :--- | :--- |
| `empty = Semaphore(N)` | $N$ (shelf capacity) | Counts the number of **empty slots** remaining on the shelf. Bakers wait on this before placing bread. |
| `full = Semaphore(0)` | $0$ (empty shelf) | Counts the number of **loaves ready** on the shelf. Customers wait on this before taking bread. |
| `mutex = Lock()` | Available (Unlocked) | Provides **mutual exclusion** to ensure only one thread accesses the shelf data structure at any time. |

---

## 🔒 Semaphore Logic & Pseudocode

Here is the pseudocode illustrating the synchronized producer and consumer algorithms:

```text
// Shared Variables
constant CAPACITY = N
empty = Semaphore(CAPACITY)   // Available shelf slots
full  = Semaphore(0)          // Loaves on shelf
mutex = Lock()                // Binary semaphore for critical section
shelf = List()                // Bounded buffer

function Baker_Producer():
    while has_loaves_to_bake():
        loaf = bake_bread()
        
        // 1. Wait for available shelf space
        wait(empty)
        
        // 2. Enter critical section (Acquire lock AFTER semaphore!)
        acquire(mutex)
        
        // --- CRITICAL SECTION ---
        shelf.append(loaf)
        log("Baker placed loaf | shelf=" + length(shelf) + "/" + CAPACITY)
        // ------------------------
        
        // 3. Exit critical section
        release(mutex)
        
        // 4. Signal that a loaf is now available
        signal(full)


function Customer_Consumer():
    while has_loaves_to_buy():
        // 1. Wait for bread to be available
        wait(full)
        
        // 2. Enter critical section (Acquire lock AFTER semaphore!)
        acquire(mutex)
        
        // --- CRITICAL SECTION ---
        loaf = shelf.pop_first()
        log("Customer took loaf | shelf=" + length(shelf) + "/" + CAPACITY)
        // ------------------------
        
        // 3. Exit critical section
        release(mutex)
        
        // 4. Signal that a shelf slot has freed up
        signal(empty)
        
        eat_bread(loaf)
```

---

## ⚠️ Why Acquisition Ordering Matters: Deadlock Analysis

### The Correct Order:
```python
empty.acquire()   # 1. First ensure space exists
mutex.acquire()   # 2. Then enter critical section
# ... modify shelf ...
mutex.release()   # 3. Leave critical section
full.release()    # 4. Notify consumers
```

### What Happens if You Reverse the Order? (DEADLOCK)

Suppose a developer wrote:
```python
# DEADLOCK TRAP:
mutex.acquire()   # Acquired lock FIRST!
empty.acquire()   # Then check if space exists
```

1. Imagine the shelf is **FULL** ($N/N$).
2. A Baker thread acquires `mutex`.
3. The Baker calls `empty.acquire()`. Since the shelf is full, `empty` value is $0$. The Baker **blocks**, **holding the `mutex` lock**.
4. A Customer thread runs to consume bread and free a slot.
5. The Customer tries to acquire `mutex` to access the shelf and call `empty.release()`.
6. However, the Customer **blocks** because the Baker is still holding `mutex`.
7. **Result**:
   - Baker is waiting for Customer to call `empty.release()`.
   - Customer is waiting for Baker to release `mutex`.
   - Neither thread can proceed. **Permanent Deadlock!**

The same catastrophe happens in reverse if a Customer acquires `mutex` before `full.acquire()` when the shelf is empty.

> **Rule of Thumb**: Always acquire condition/counting semaphores (`empty`/`full`) **BEFORE** acquiring the mutual exclusion lock (`mutex`).

---

## 🚨 The `--no-sync` Flag & Race Conditions

When running with `--no-sync`, the mutex is disabled while semaphores are retained or shelf operations run unguarded:
- Multiple threads read and modify the shared `shelf.buffer` list simultaneously.
- **Lost Updates**: Two bakers may append simultaneously, causing one loaf to overwrite another in internal buffers or calculate incorrect lengths.
- **Race Condition Underflow**: Two customers may attempt `shelf.buffer.pop(0)` concurrently; one succeeds and the other encounters an empty list or pops an unintended item.
- **Inconsistent State**: Printed logs might report impossible states (e.g. `shelf=6/5` or `shelf=-1/5`).

---

## ⚖️ Comparison: `bakery.py` vs `bakery_queue.py`

| Aspect | `bakery.py` (Semaphores + Mutex) | `bakery_queue.py` (`queue.Queue`) |
| :--- | :--- | :--- |
| **Abstraction Level** | Low-level foundational synchronization | High-level thread-safe container |
| **Primitives Used** | `threading.Semaphore`, `threading.Lock` | Built-in `queue.Queue(maxsize=N)` |
| **Deadlock Risk** | Possible if developer swaps acquire order | Zero (handled internally via `Condition` variables) |
| **Educational Value** | Directly demonstrates Dijkstra's classical OS algorithm | Demonstrates standard production Python idiom |

---

## 🚀 How to Run

### 1. Standard Run (Default Configuration)
```bash
python3 bakery.py
```
*(Defaults: `--shelf-size 5 --bakers 2 --customers 2 --loaves-per-baker 5`)*

### 2. Custom Configuration with Uneven Consumer Split
```bash
python3 bakery.py --shelf-size 4 --bakers 3 --customers 2 --loaves-per-baker 4
```
*(Total produced = 12 loaves. Customers automatically split: Cust-1 gets 6, Cust-2 gets 6).*

### 3. Asymmetric Split (e.g., 3 Bakers × 5 Loaves = 15 loaves, 2 Customers)
```bash
python3 bakery.py --shelf-size 3 --bakers 3 --customers 2 --loaves-per-baker 5
```
*(Cust-1 buys 8, Cust-2 buys 7. Clean termination!)*

### 4. Demonstrating Race Conditions with `--no-sync`
```bash
python3 bakery.py --shelf-size 3 --bakers 4 --customers 4 --loaves-per-baker 6 --no-sync
```

### 5. Running the `queue.Queue` Alternative
```bash
python3 bakery_queue.py --shelf-size 5 --bakers 2 --customers 2 --loaves-per-baker 5
```
