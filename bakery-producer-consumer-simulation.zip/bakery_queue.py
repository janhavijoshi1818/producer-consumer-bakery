#!/usr/bin/env python3
"""
Bakery Producer-Consumer Simulation using queue.Queue
Demonstrates the high-level, thread-safe queue approach to bounded-buffer synchronization.

For comparison with bakery.py (which uses raw Semaphores and Mutex):
  - Python's queue.Queue encapsulates bounded buffer logic, internal condition
    variables (not_full, not_empty), and a reentrant lock (mutex).
  - queue.put(item, block=True) automatically blocks when queue size reaches maxsize.
  - queue.get(block=True) automatically blocks when the queue is empty.
  - No manual semaphore counting or deadlock-prone lock ordering is needed.
"""

import argparse
import datetime
import queue
import random
import sys
import threading
import time
from typing import List


def get_timestamp() -> str:
    """Return formatted timestamp with milliseconds."""
    return datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]


def log_event(message: str) -> None:
    """Thread-safe stdout logging."""
    sys.stdout.write(f"[{get_timestamp()}] {message}\n")
    sys.stdout.flush()


def baker_worker(
    baker_id: int,
    loaves_to_bake: int,
    shelf_queue: queue.Queue,
    shelf_capacity: int,
    bake_delay_range: tuple = (0.05, 0.20),
) -> None:
    """
    Producer thread function using queue.Queue.
    """
    baker_name = f"Baker-{baker_id}"
    
    for loaf_num in range(1, loaves_to_bake + 1):
        loaf_id = f"{baker_name}-loaf{loaf_num}"
        
        # 1. Simulate baking time
        time.sleep(random.uniform(*bake_delay_range))
        
        # 2. Check if blocking will occur
        # If queue is full, log blocking notice before blocking on put()
        if shelf_queue.full():
            log_event(f"⚠️  {baker_name} BLOCKED: queue is full ({shelf_capacity}/{shelf_capacity}). Waiting...")
        
        # queue.put() handles synchronization internally
        shelf_queue.put(loaf_id, block=True)
        
        current_size = shelf_queue.qsize()
        log_event(f"🍞 {baker_name:<7} placed {loaf_id} | shelf={current_size}/{shelf_capacity}")


def customer_worker(
    customer_id: int,
    loaves_to_buy: int,
    shelf_queue: queue.Queue,
    shelf_capacity: int,
    eat_delay_range: tuple = (0.05, 0.20),
) -> None:
    """
    Consumer thread function using queue.Queue.
    """
    customer_name = f"Cust-{customer_id}"
    
    for _ in range(loaves_to_buy):
        # If queue is empty, log blocking notice before blocking on get()
        if shelf_queue.empty():
            log_event(f"⏳ {customer_name} BLOCKED: queue is empty (0/{shelf_capacity}). Waiting...")

        # queue.get() handles synchronization internally
        loaf_taken = shelf_queue.get(block=True)
        shelf_queue.task_done()
        
        remaining_size = shelf_queue.qsize()
        log_event(f"🛒 {customer_name:<7} took   {loaf_taken} | shelf={remaining_size}/{shelf_capacity}")
        
        # Simulate eating
        time.sleep(random.uniform(*eat_delay_range))


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Bakery Producer-Consumer Simulation using Python's queue.Queue"
    )
    parser.add_argument(
        "--shelf-size",
        type=int,
        default=5,
        help="Capacity of the bakery shelf (queue maxsize). Default: 5",
    )
    parser.add_argument(
        "--bakers",
        type=int,
        default=2,
        help="Number of producer threads (bakers). Default: 2",
    )
    parser.add_argument(
        "--customers",
        type=int,
        default=2,
        help="Number of consumer threads (customers). Default: 2",
    )
    parser.add_argument(
        "--loaves-per-baker",
        type=int,
        default=5,
        help="Number of loaves each baker will produce. Default: 5",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_arguments()

    if args.shelf_size <= 0:
        sys.exit("Error: --shelf-size must be a positive integer.")
    if args.bakers <= 0:
        sys.exit("Error: --bakers must be a positive integer.")
    if args.customers <= 0:
        sys.exit("Error: --customers must be a positive integer.")
    if args.loaves_per_baker <= 0:
        sys.exit("Error: --loaves-per-baker must be a positive integer.")

    total_loaves_to_produce = args.bakers * args.loaves_per_baker

    # Handle uneven split among customers
    base_loaves_per_cust = total_loaves_to_produce // args.customers
    remainder_loaves = total_loaves_to_produce % args.customers
    customer_quotas = [
        base_loaves_per_cust + (1 if i < remainder_loaves else 0)
        for i in range(args.customers)
    ]
    total_loaves_to_consume = sum(customer_quotas)

    # Initialize thread-safe bounded FIFO queue
    shelf_queue = queue.Queue(maxsize=args.shelf_size)

    print("=" * 70)
    print("🥐 BAKERY PRODUCER-CONSUMER SIMULATION (using queue.Queue)")
    print("=" * 70)
    print("Configuration:")
    print(f"  • Shelf Capacity (N) : {args.shelf_size} loaves (Queue maxsize)")
    print(f"  • Bakers (Producers) : {args.bakers} threads ({args.loaves_per_baker} loaves each)")
    print(f"  • Customers (Consumers): {args.customers} threads (quotas: {customer_quotas})")
    print(f"  • Total Loaves       : {total_loaves_to_produce} produced == {total_loaves_to_consume} consumed")
    print(f"  • Synchronization    : queue.Queue (internal Condition variables & Lock)")
    print("=" * 70)

    start_time = time.time()

    baker_threads = [
        threading.Thread(
            target=baker_worker,
            args=(i + 1, args.loaves_per_baker, shelf_queue, args.shelf_size),
            name=f"BakerThread-{i + 1}",
        )
        for i in range(args.bakers)
    ]

    customer_threads = [
        threading.Thread(
            target=customer_worker,
            args=(i + 1, customer_quotas[i], shelf_queue, args.shelf_size),
            name=f"CustomerThread-{i + 1}",
        )
        for i in range(args.customers)
    ]

    for t in baker_threads:
        t.start()
    for t in customer_threads:
        t.start()

    for t in baker_threads:
        t.join()
    for t in customer_threads:
        t.join()

    elapsed = time.time() - start_time

    print("=" * 70)
    print("📋 SIMULATION SUMMARY")
    print("=" * 70)
    print(f"Total Produced : {total_loaves_to_produce} loaves")
    print(f"Total Consumed : {total_loaves_to_consume} loaves")
    print(f"Final Shelf    : {shelf_queue.qsize()}/{args.shelf_size} loaves remaining in queue")
    print(f"Execution Time : {elapsed:.2f} seconds")
    print("\n💡 Comparison with bakery.py (Semaphores + Mutex):")
    print("  • queue.Queue encapsulates all low-level synchronization details:")
    print("    - Uses threading.Condition for not_full and not_empty")
    print("    - Uses internal Lock to protect queue state (collections.deque)")
    print("    - Automatically prevents deadlocks that could arise from incorrect lock ordering.")
    print("  • bakery.py demonstrates the explicit foundational primitives (Dijkstra's counting semaphores).")
    print("=" * 70)


if __name__ == "__main__":
    main()
