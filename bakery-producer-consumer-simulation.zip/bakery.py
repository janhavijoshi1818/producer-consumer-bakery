#!/usr/bin/env python3
"""
Bakery Producer-Consumer Simulation
Demonstrates the classic Bounded-Buffer synchronization problem using POSIX-style
counting semaphores and a mutual exclusion lock in Python's threading library.

Scenario:
  - Bakers (Producers) bake fresh loaves and place them on a bounded shelf.
  - Customers (Consumers) take loaves from the shelf.
  - Shelf is a shared bounded buffer of fixed capacity N.

Synchronization Primitives:
  1. empty = threading.Semaphore(N): Tracks available slots on the shelf.
  2. full  = threading.Semaphore(0): Tracks available loaves ready to be taken.
  3. mutex = threading.Lock():       Protects the shelf critical section.
"""

import argparse
import datetime
import random
import sys
import threading
import time
from typing import List, Optional


def get_timestamp() -> str:
    """Return formatted timestamp with milliseconds."""
    return datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]


def log_event(message: str) -> None:
    """Thread-safe stdout logging."""
    sys.stdout.write(f"[{get_timestamp()}] {message}\n")
    sys.stdout.flush()


class BakeryShelf:
    """
    Bounded buffer representation for the bakery shelf.
    """
    def __init__(self, capacity: int, use_mutex: bool = True):
        self.capacity: int = capacity
        self.use_mutex: bool = use_mutex
        self.buffer: List[str] = []
        
        # Synchronization primitives
        # empty starts at capacity (all slots free)
        self.empty: threading.Semaphore = threading.Semaphore(capacity)
        # full starts at 0 (no loaves initially)
        self.full: threading.Semaphore = threading.Semaphore(0)
        # mutex protects shared buffer access
        self.mutex: threading.Lock = threading.Lock()
        
        # Race condition detection counters (especially visible in --no-sync)
        self.race_anomalies: List[str] = []
        self.lock_for_stats: threading.Lock = threading.Lock()

    def record_anomaly(self, text: str) -> None:
        with self.lock_for_stats:
            self.race_anomalies.append(text)


def baker_worker(
    baker_id: int,
    loaves_to_bake: int,
    shelf: BakeryShelf,
    bake_delay_range: tuple = (0.05, 0.20),
    shelf_action_delay: float = 0.005,
) -> None:
    """
    Producer thread function.
    Bakes a specified number of loaves and places each on the shelf.
    """
    baker_name = f"Baker-{baker_id}"
    
    for loaf_num in range(1, loaves_to_bake + 1):
        loaf_id = f"{baker_name}-loaf{loaf_num}"
        
        # 1. Simulate baking time outside of any lock/semaphore
        time.sleep(random.uniform(*bake_delay_range))
        
        # 2. Check if the shelf is full before acquiring
        # We attempt a non-blocking acquire first to log blocking behavior cleanly.
        if not shelf.empty.acquire(blocking=False):
            log_event(f"⚠️  {baker_name} BLOCKED: shelf is full ({shelf.capacity}/{shelf.capacity}). Waiting for space...")
            shelf.empty.acquire()  # Now block until a customer takes a loaf and signals empty

        # =========================================================================
        # CRITICAL SECTION ACQUISITION ORDER EXPLANATION:
        # We MUST acquire `empty` BEFORE `mutex`!
        #
        # Why?
        # If we acquired `mutex` first and then `empty.acquire()` while the shelf is full:
        #   1. Baker holds `mutex`.
        #   2. Baker blocks waiting on `empty`.
        #   3. Customer tries to take bread to free a slot, but Customer MUST acquire
        #      `mutex` to access the shelf and call `empty.release()`.
        #   4. Customer blocks waiting for `mutex` (which Baker holds).
        #   => DEADLOCK! Neither thread can make progress.
        #
        # Acquiring `empty` first guarantees that the Baker only enters the critical
        # section when there is a confirmed free slot on the shelf.
        # =========================================================================
        
        if shelf.use_mutex:
            shelf.mutex.acquire()
            
        try:
            # Critical Section: place loaf onto shelf
            # In --no-sync mode, a tiny delay exacerbates the race window
            if not shelf.use_mutex:
                time.sleep(shelf_action_delay)

            # Check for buffer overflow race condition
            current_count = len(shelf.buffer)
            if current_count >= shelf.capacity:
                anomaly = f"RACE HAZARD: {baker_name} placed loaf when buffer size was already {current_count}/{shelf.capacity}!"
                shelf.record_anomaly(anomaly)
                log_event(f"🚨 {anomaly}")

            shelf.buffer.append(loaf_id)
            new_count = len(shelf.buffer)
            shelf_repr = f"shelf={new_count}/{shelf.capacity}"
            log_event(f"🍞 {baker_name:<7} placed {loaf_id} | {shelf_repr}")
            
        finally:
            if shelf.use_mutex:
                shelf.mutex.release()
                
        # 3. Signal to waiting customers that a loaf is available
        shelf.full.release()


def customer_worker(
    customer_id: int,
    loaves_to_buy: int,
    shelf: BakeryShelf,
    eat_delay_range: tuple = (0.05, 0.20),
    shelf_action_delay: float = 0.005,
) -> None:
    """
    Consumer thread function.
    Takes a specified number of loaves from the shelf and consumes them.
    """
    customer_name = f"Cust-{customer_id}"
    
    for _ in range(loaves_to_buy):
        # 1. Check if the shelf is empty before acquiring
        if not shelf.full.acquire(blocking=False):
            log_event(f"⏳ {customer_name} BLOCKED: shelf is empty (0/{shelf.capacity}). Waiting for fresh bread...")
            shelf.full.acquire()  # Block until a baker produces a loaf and signals full

        # =========================================================================
        # CRITICAL SECTION ACQUISITION ORDER EXPLANATION:
        # We MUST acquire `full` BEFORE `mutex`!
        #
        # Why?
        # If Customer acquired `mutex` first and then `full.acquire()` while shelf is empty:
        #   1. Customer holds `mutex`.
        #   2. Customer blocks waiting on `full`.
        #   3. Baker tries to place freshly baked bread on the shelf, but needs `mutex`
        #      to access the shelf buffer and call `full.release()`.
        #   4. Baker blocks on `mutex` (which Customer holds).
        #   => DEADLOCK! Neither thread can proceed.
        #
        # Acquiring `full` first guarantees Customer enters the critical section
        # only when a loaf is physically present to be consumed.
        # =========================================================================

        if shelf.use_mutex:
            shelf.mutex.acquire()
            
        loaf_taken: Optional[str] = None
        try:
            # Critical Section: take loaf from shelf (FIFO from head)
            if not shelf.use_mutex:
                time.sleep(shelf_action_delay)

            if len(shelf.buffer) == 0:
                anomaly = f"RACE HAZARD: {customer_name} tried to pop from an EMPTY shelf!"
                shelf.record_anomaly(anomaly)
                log_event(f"🚨 {anomaly}")
            else:
                loaf_taken = shelf.buffer.pop(0)

            remaining_count = len(shelf.buffer)
            shelf_repr = f"shelf={remaining_count}/{shelf.capacity}"
            log_event(f"🛒 {customer_name:<7} took   {loaf_taken or 'NONE (RACE)'} | {shelf_repr}")
            
        finally:
            if shelf.use_mutex:
                shelf.mutex.release()

        # 2. Signal to waiting bakers that a shelf slot has freed up
        shelf.empty.release()
        
        # 3. Simulate eating/consuming time outside critical section
        time.sleep(random.uniform(*eat_delay_range))


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Bakery Producer-Consumer Bounded-Buffer Simulation (Semaphores & Mutex)"
    )
    parser.add_argument(
        "--shelf-size",
        type=int,
        default=5,
        help="Capacity of the bakery shelf (bounded buffer size N). Default: 5",
    )
    parser.add_argument(
        "--bakers",
        type=int,
        default=2,
        help="Number of producer threads (bakers). Default: 2",
    )
    parser.add_argument(
        "--customers",
        type=int,
        default=2,
        help="Number of consumer threads (customers). Default: 2",
    )
    parser.add_argument(
        "--loaves-per-baker",
        type=int,
        default=5,
        help="Number of loaves each baker will produce. Default: 5",
    )
    parser.add_argument(
        "--no-sync",
        action="store_true",
        help="Disable the mutex lock around the shelf to demonstrate race conditions.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_arguments()
    
    if args.shelf_size <= 0:
        sys.exit("Error: --shelf-size must be a positive integer.")
    if args.bakers <= 0:
        sys.exit("Error: --bakers must be a positive integer.")
    if args.customers <= 0:
        sys.exit("Error: --customers must be a positive integer.")
    if args.loaves_per_baker <= 0:
        sys.exit("Error: --loaves-per-baker must be a positive integer.")

    total_loaves_to_produce = args.bakers * args.loaves_per_baker

    # Handle uneven split among customers so that total produced == total consumed
    # Every loaf baked will be purchased; all threads terminate cleanly.
    base_loaves_per_cust = total_loaves_to_produce // args.customers
    remainder_loaves = total_loaves_to_produce % args.customers
    customer_quotas = [
        base_loaves_per_cust + (1 if i < remainder_loaves else 0)
        for i in range(args.customers)
    ]
    total_loaves_to_consume = sum(customer_quotas)

    assert total_loaves_to_produce == total_loaves_to_consume

    use_mutex = not args.no_sync
    shelf = BakeryShelf(capacity=args.shelf_size, use_mutex=use_mutex)

    print("=" * 70)
    print("🥐 BAKERY PRODUCER-CONSUMER BOUNDED-BUFFER SIMULATION")
    print("=" * 70)
    print(f"Configuration:")
    print(f"  • Shelf Capacity (N) : {args.shelf_size} loaves")
    print(f"  • Bakers (Producers) : {args.bakers} threads ({args.loaves_per_baker} loaves each)")
    print(f"  • Customers (Consumers): {args.customers} threads (quotas: {customer_quotas})")
    print(f"  • Total Loaves       : {total_loaves_to_produce} produced == {total_loaves_to_consume} consumed")
    print(f"  • Synchronization    : {'MUTEX + SEMAPHORES (Thread-safe)' if use_mutex else 'NO MUTEX (--no-sync: Race Condition Demo)'}")
    print("=" * 70)
    if not use_mutex:
        print("⚠️  WARNING: Running in --no-sync mode!")
        print("   The shelf critical section is unprotected by a mutex lock.")
        print("   Watch for race conditions, corrupted buffers, or unexpected states.")
        print("-" * 70)

    start_time = time.time()

    # Create threads
    baker_threads = [
        threading.Thread(
            target=baker_worker,
            args=(i + 1, args.loaves_per_baker, shelf),
            name=f"BakerThread-{i + 1}",
        )
        for i in range(args.bakers)
    ]

    customer_threads = [
        threading.Thread(
            target=customer_worker,
            args=(i + 1, customer_quotas[i], shelf),
            name=f"CustomerThread-{i + 1}",
        )
        for i in range(args.customers)
    ]

    # Start all threads
    for t in baker_threads:
        t.start()
    for t in customer_threads:
        t.start()

    # Wait for all threads to terminate cleanly
    for t in baker_threads:
        t.join()
    for t in customer_threads:
        t.join()

    elapsed = time.time() - start_time

    print("=" * 70)
    print("📋 SIMULATION SUMMARY")
    print("=" * 70)
    print(f"Total Produced : {total_loaves_to_produce} loaves")
    print(f"Total Consumed : {total_loaves_to_consume} loaves")
    print(f"Final Shelf    : {len(shelf.buffer)}/{shelf.capacity} loaves remaining on shelf")
    print(f"Items on Shelf : {shelf.buffer}")
    print(f"Execution Time : {elapsed:.2f} seconds")

    if not use_mutex:
        print("\n🔎 RACE CONDITION ANALYSIS (--no-sync):")
        if shelf.race_anomalies:
            print(f"Detected {len(shelf.race_anomalies)} race condition anomalies during execution:")
            for a in shelf.race_anomalies[:5]:
                print(f"  • {a}")
            if len(shelf.race_anomalies) > 5:
                print(f"  ... and {len(shelf.race_anomalies) - 5} more.")
        else:
            print("Note: In this specific run, GIL or scheduling avoided a fatal crash,")
            print("but without a mutex, atomicity is NOT guaranteed across OS context switches.")
        print("\nWhat went wrong without the mutex?")
        print("1. Non-atomic buffer operations: Python's list.append() and list.pop(0) can")
        print("   interleave during thread context switches, leading to overwritten elements,")
        print("   lost updates, or attempting to pop from an empty list.")
        print("2. Desynchronized state: A thread might read len(buffer) while another is halfway")
        print("   through modifying it, violating bounded-buffer invariants (capacity limits).")
        print("3. Mutex is essential to ensure only ONE thread accesses the shelf structure at a time.")
    else:
        print("\n✅ Verification Successful: All loaves safely produced, synchronized, and consumed!")
        print("   Buffer stayed strictly within bounded capacity [0, N] without deadlocks or races.")
    print("=" * 70)


if __name__ == "__main__":
    main()
